package com.aof.mcinabox.gamecontroller.input.otg;

public class GamePad {

}
