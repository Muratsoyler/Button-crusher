package com.aof.mcinabox.gamecontroller.input.screen.Button;

import android.content.Context;
import android.util.AttributeSet;

import androidx.annotation.Nullable;

public class CrossButton extends BaseButton {

    public CrossButton(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }
}
