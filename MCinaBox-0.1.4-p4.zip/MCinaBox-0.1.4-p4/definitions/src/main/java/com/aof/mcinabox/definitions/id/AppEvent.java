package com.aof.mcinabox.definitions.id;

import com.aof.mcinabox.definitions.id.key.KeyEvent;
import com.aof.mcinabox.definitions.id.key.KeyMode;

public interface AppEvent extends KeyEvent , KeyMode {
}
