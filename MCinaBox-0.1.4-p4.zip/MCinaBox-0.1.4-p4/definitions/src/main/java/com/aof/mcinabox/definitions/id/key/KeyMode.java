package com.aof.mcinabox.definitions.id.key;

public interface KeyMode {
    int MARK_INPUT_MODE_CATCH = 0;  //boat的捕获模式
    int MARK_INPUT_MODE_ALONE = 1;  //boat的独立模式
}
