package com.aof.mcinabox.definitions.map;

public interface MouseMap {
    String
            MOUSEMAP_BUTTON_LEFT = "MOUSE_BUTTON_LEFT",
            MOUSEMAP_BUTTON_RIGHT = "MOUSE_BUTTON_RIGHT",
            MOUSEMAP_BUTTON_MIDDLE = "MOUSE_BUTTON_MIDDLE",
            MOUSEMAP_WHEEL_UP = "MOUSE_WHEEL_UP",
            MOUSEMAP_WHEEL_DOWN = "MOUSE_WHEEL_DOWN";

}
