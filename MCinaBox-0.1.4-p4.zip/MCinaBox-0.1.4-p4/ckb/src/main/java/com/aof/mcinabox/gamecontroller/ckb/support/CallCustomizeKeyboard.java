package com.aof.mcinabox.gamecontroller.ckb.support;

import android.view.View;

public interface CallCustomizeKeyboard {
    void addView(View view);
}
