package com.aof.mcinabox.gamecontroller.ckb.support;

import java.util.ArrayList;

public class GameButtonArray<GameButton> extends ArrayList<GameButton> {

}
