package com.aof.mcinabox.launcher.launch.support;

import com.aof.mcinabox.definitions.models.BoatArgs;

import java.io.Serializable;

public class BoatArgsJson extends BoatArgs implements Serializable {}
