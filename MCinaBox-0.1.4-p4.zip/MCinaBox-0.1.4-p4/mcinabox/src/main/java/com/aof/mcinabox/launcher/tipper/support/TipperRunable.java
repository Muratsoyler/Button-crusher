package com.aof.mcinabox.launcher.tipper.support;

public interface TipperRunable {

    public void run();

}
