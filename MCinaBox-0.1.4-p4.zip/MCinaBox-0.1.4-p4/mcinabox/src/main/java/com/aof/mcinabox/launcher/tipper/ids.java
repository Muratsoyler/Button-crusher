package com.aof.mcinabox.launcher.tipper;

public class ids {
    //TIPPER_ID = 10 -> UserUI
}
