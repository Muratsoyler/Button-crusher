package com.aof.mcinabox.launcher.user.support;

public class ErrorResponse {
    public String error;
    public String errorMessage;
    public String cause;
}