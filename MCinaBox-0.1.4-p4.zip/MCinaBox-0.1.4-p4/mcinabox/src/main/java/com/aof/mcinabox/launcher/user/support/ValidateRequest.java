package com.aof.mcinabox.launcher.user.support;

public class ValidateRequest {

    public String accessToken;

    public ValidateRequest(String accessToken) {
        this.accessToken = accessToken;
    }
}
