package com.aof.mcinabox.launcher.user.support;

public class RefreshResponse extends AuthenticateResponse {
}
