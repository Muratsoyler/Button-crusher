package com.aof.mcinabox.launcher.user.support;

public class Profile {
    public String id;
    public String name;

    public Profile(String id, String name) {
        this.id = id;
        this.name = name;
    }
}