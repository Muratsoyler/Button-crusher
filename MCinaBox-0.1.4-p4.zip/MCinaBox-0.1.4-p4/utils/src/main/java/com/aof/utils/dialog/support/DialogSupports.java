package com.aof.utils.dialog.support;

public class DialogSupports {

    public void runWhenPositive(){}
    public void runWhenNegative(){}
    public void runWhenItemsSelected(int pos){}
    public void runWhenItemsSelected(Object obj){}
    public void runWhenItemsSelected(){}
    public void runWhenColorSelected(int[] colors){}
}
